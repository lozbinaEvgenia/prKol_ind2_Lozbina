﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace collec_lozbina
{
    class Person
    {
        private string fam;
        private string name;
        private string ot;
        private string pol;
        private int age;
        private int zp;

        public Person(string fam, string name, string ot, string pol, int age, int zp)
        {
            this.fam = fam;
            this.name = name;
            this.ot = ot;
            this.pol = pol;
            this.age = age;
            this.zp = zp;
        }
        public void set_lastname(string f)
        {
            this.fam = f;
        }
        public string get_lastname()
        {
            return this.fam;
        }
        public void set_name(string f)
        {
            this.name = f;
        }
        public string get_name()
        {
            return this.name;
        }
        public void set_otfather(string f)
        {
            this.ot = f;
        }
        public string get_otfather()
        {
            return this.ot;
        }
        public void set_pol(string f)
        {
            this.pol = f;
        }
        public string get_pol()
        {
            return this.pol;
        }
        public void set_age(int f)
        {
            this.age = f;
        }
        public int get_age()
        {
            return this.age;
        }

        public void set_zp(int f)
        {
            this.zp = f;
        }
        public int get_zp()
        {
            return this.zp;
        }

    }
}
