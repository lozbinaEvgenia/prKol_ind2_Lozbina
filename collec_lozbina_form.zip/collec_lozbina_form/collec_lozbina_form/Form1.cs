﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace collec_lozbina_form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Queue<Student> stud = new Queue<Student>();
            string file = "students.txt";
            if (!File.Exists(file))
            {
                if (!string.IsNullOrEmpty(file))
                {
                    MessageBox.Show("файл пустой", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                MessageBox.Show("файл не найден", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] s = File.ReadAllLines(file);
                foreach (string ss in s)
                {
                    Student p1 = new Student("", "", "", "", 0, 0, 0);
                    string[] studd = ss.Split(' ');
                    string fam = studd[0];
                    p1.set_lastname(fam);
                    string name = studd[1];
                    p1.set_name(name);
                    string ot = studd[2];
                    p1.set_otfather(ot);
                    string groug = studd[3];
                    p1.set_groug(groug);
                    int mat = Convert.ToInt32(studd[4]);
                    p1.set_mat(mat);
                    int lit = Convert.ToInt32(studd[5]);
                    p1.set_lit(lit);
                    int fiz = Convert.ToInt32(studd[5]);
                    p1.set_fiz(fiz);
                    listBox1.Items.Add($"ФИО: {p1.get_lastname()} {p1.get_name()} {p1.get_otfather()} Группа: {p1.get_groug()} Математика: {p1.get_mat()} Литература: {p1.get_lit()} Физика: {p1.get_fiz()}");

                    stud.Enqueue(new Student(fam, name, ot, groug, mat, lit, fiz));
                }
                var uspeh = from p in stud
                            where ((p.get_mat()) > 3 && (p.get_lit()) > 3 && (p.get_fiz()) > 3)
                            select p;
                var neuspeh = from g in stud
                              where ((g.get_mat()) <= 3 || (g.get_lit()) <= 3 || (g.get_fiz()) <= 3)
                              select g;
                foreach (var y in uspeh)
                {
                    listBox2.Items.Add($"ФИО: {y.get_lastname()} {y.get_name()} {y.get_otfather()} Группа: {y.get_groug()} Математика: {y.get_mat()} Литература: {y.get_lit()} Физика: {y.get_fiz()}");
                }
                foreach (var n in neuspeh)
                {
                    listBox2.Items.Add($"ФИО: {n.get_lastname()} {n.get_name()} {n.get_otfather()} Группа: {n.get_groug()} Математика: {n.get_mat()} Литература: {n.get_lit()} Физика: {n.get_fiz()}");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stack<int> f= new Stack<int>();
            Stack<int> s = new Stack<int>();
            Random r = new Random();
            int max, min, rez;
            string ff = "", ss = "";
            string file1 = "formula.txt";
            if (!File.Exists(file1))
            {
                if (!string.IsNullOrEmpty(file1))
                {
                MessageBox.Show("файл пустой", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                MessageBox.Show("файл не найден", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string s1 = File.ReadAllText(file1);
                int index = s1.IndexOf("<");
                int num = Convert.ToInt32(s1[index + 1]) - 48;
                int i = 0;
                while (i < num)
                {
                    f.Push(r.Next(0, 9));
                    s.Push(r.Next(0, 9));
                    i++;
                }
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        {
                            max = f.Max();
                            min = s.Max();
                            if (min > max) rez = min;
                            else rez = max;
                            while (f.Count > 0)
                            {
                                ff += $"{f.Pop()} ";
                                ss += $"{s.Pop()} ";
                            }
                            listBox3.Items.Add($"M(M({ff}), M({ss}) = {rez}");
                            break;
                            
                        }
                    case 1:
                        {
                            max = f.Max();
                            min = s.Min();
                            if (min > max) rez = min;
                            else rez = max;
                            while (f.Count > 0)
                            {
                                ff += $"{f.Pop()} ";
                                ss += $"{s.Pop()} ";
                            }
                            listBox3.Items.Add($"M(M({ff}), m({ss}) = {rez}");
                            break;
                        }
                    case 2:
                        {
                            max = f.Min();
                            min = s.Min();
                            if (min > max) rez = min;
                            else rez = max;
                            while (f.Count > 0)
                            {
                                ff += $"{f.Pop()} ";
                                ss += $"{s.Pop()} ";
                            }
                            listBox3.Items.Add($"M(m({ff}), m({ss}) = {rez}");
                            break;
                        }
                    case 3:
                        {
                            max = f.Max();
                            min = s.Max();
                            if (min < max) rez = min;
                            else rez = max;
                            while (f.Count > 0)
                            {
                                ff += $"{f.Pop()} ";
                                ss += $"{s.Pop()} ";
                            }
                            listBox3.Items.Add($"m(M({ff}), M({ss}) = {rez}");
                            break;
                          
                        }
                    case 4:
                        {
                            max = f.Max();
                            min = s.Min();
                            if (min < max) rez = min;
                            else rez = max;
                            while (f.Count > 0)
                            {
                                ff += $"{f.Pop()} ";
                                ss += $"{s.Pop()} ";
                            }
                            listBox3.Items.Add($"m(M({ff}), m({ss}) = {rez}");
                            break;
                        }
                    case 5:
                        {
                            max = f.Min();
                            min = s.Min();
                            if (min < max) rez = min;
                            else rez = max;
                            while (f.Count > 0)
                            {
                                ff += $"{f.Pop()} ";
                                ss += $"{s.Pop()} ";
                            }
                            listBox3.Items.Add($"m(m({ff}), m({ss}) = {rez}");
                            break;
                        }
                    default: {
                            MessageBox.Show("выберите формулу!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        }
                }
            }
        }
    }
}
